<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    $posts = \App\Blog::orderby('created_at','desc')->paginate(10);
    return view('welcome',compact('posts'));
});
Route::resource('blog','BlogController');
Route::post('comment/store','CommentController@store')->name('comment.store');
/*
Route::get('/hello','HomeController@hello');

Route::resource('blog', 'BlogController');
*/

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::get('/hello', 'HomeController@index1');