<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comment;

class CommentController extends Controller
{
    function __construct()
    {
        $this->middleware('auth');
    }
    function store(Request $request){
        $comment = new Comment();
        $comment->comment = $request->comment;
        $comment->user_id = \Auth::user()->id;
        $comment->blog_post_id = $request->blog_post_id;
        $comment->save();

        return redirect()->back();

    }
}
