<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    function post(){
        return $this->belongsTo('App\Blog','blog_post_id','id');
    }
    function user(){
        return $this->belongsTo('App\User');
    }
}
