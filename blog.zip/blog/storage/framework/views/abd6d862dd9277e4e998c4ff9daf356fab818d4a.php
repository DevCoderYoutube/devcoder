<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <h1>Welcome to Blog Application</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="panel panel-default">
                    <div class="panel-heading"><h4><?php echo e($post->title); ?></h4></div>
                    <div class="panel-body"><?php echo e($post->description); ?></div>
                    <div class="panel-footer"><h4>Comments</h4>
                        <ul>
                            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li>
                                    <?php echo e($comment->comment); ?><br>
                                    Posted by <?php echo e($comment->user->name); ?> before <?php echo e(\Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    </div>
                    <div class="panel-footer">
                        <?php if(\Auth::guest()): ?>
                            <a href="/login">Login to comment</a>
                        <?php else: ?>
                            <form method="post" action="<?php echo e(route('comment.store')); ?>">
                                <input type="hidden" name="blog_post_id" value="<?php echo e($post->id); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <input class="form-control" type="text" name="comment" required />
                                </div>
                                <input class="form-control" type="submit" value="Comment" required />
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php echo $posts->links(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>