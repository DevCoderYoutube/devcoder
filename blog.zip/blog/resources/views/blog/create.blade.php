@extends('layout')
@section('content')
    <div class="row">
        <h3>Create New Post</h3>
    </div>
    <div class="row">
        <form class="" action="{{route('blog.store')}}" method="post">
            {{csrf_field()}}
            <div class="form-group">
                <input type="text" name="title" class="form-control" placeholder="Enter Title here">
                {!! $errors->first('title', '<p class="help-block">:message</p>') !!}
            </div>
            <div class="form-group">
                <input type="text" name="description" class="form-control" placeholder="Enter Description here">
                {!! $errors->first('description', '<p class="help-block">:message</p>') !!}
            </div>
            <div>
                <input type="submit" class="btn btn-primary" value="save">
            </div>
        </form>
    </div>
    @stop