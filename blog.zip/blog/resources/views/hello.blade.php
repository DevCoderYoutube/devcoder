<!DOCTYPE html>
<html>
<head>
    <title>seller</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/font-awesome.css')}}">
    <link rel='stylesheet' id='camera-css'  href="{{asset('css/camera.css')}}" type='text/css' media='all'>

    <link rel="stylesheet" type="text/css" href="{{asset('css/slicknav.css')}}">
    <link rel="stylesheet" href="{{('css/prettyPhoto.css')}}" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="{{asset('css/style.css')}}">


    <script type="text/javascript" src="{{asset('js/jquery-1.8.3.min.js')}}"></script>

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700|Open+Sans:700' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="{{asset('js/jquery.mobile.customized.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/jquery.easing.1.3.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/camera.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/myscript.js')}}"></script>
    <script src="{{asset('js/sorting.js')}}" type="text/javascript"></script>
    <script src="{{asset('js/jquery.isotope.js')}}" type="text/javascript"></script>

</head>
<body>
<div class="container">
    <div class="row">

        <div class="col-sm-4 col-md-4">

        </div>
        <div class="col-sm-4 col-md-4">

            <h1 style="color: white;">Buyer profile</h1>
            <form class="form-horizontal">
                <div class="form-group">
                    <label class="control-label" for="email" style="color: white;">First Name:</label>

                    <input type="text" class="form-control" id="fname" placeholder="First Name">

                </div>
                <div class="form-group">
                    <label class="control-label" for="name" style="color: white;">Second Name:</label>

                    <input type="text" class="form-control" id="sname" placeholder="Second Name">

                </div>
                <div class="form-group">
                    <label class="control-label" for="email" style="color: white;">Email id:</label>

                    <input type="email" class="form-control" id="email" placeholder="email">

                </div>
                <div class="form-group">
                    <label class="control-label" for="num" style="color: white;">Phone No:</label>

                    <input type="text" class="form-control" id="Phone" placeholder="Phone number">

                </div>
                <div class="form-group">
                    <label class="control-label" for="email" style="color: white;">Skills:</label>

                    <input type="text" class="form-control" id="skill" placeholder="Skills">

                </div>
                <div class="form-group">
                    <label class="control-label" for="qualification" style="color: white;">Qualification:</label>

                    <input type="text" class="form-control" id="qualify" placeholder="education">

                </div>
                <div class="form-group">
                    <label class="control-label" for="email" style="color: white;">Country:</label>

                    <input type="text" class="form-control" id="cname" placeholder="Country Name">

                </div>
                <div class="form-group">
                    <label class="control-label" for="pwd" style="color: white;">City:</label>

                    <input type="text" class="form-control" id="cityname" placeholder="City Name">

                </div>
                <div class="form-group">
                    <label class="control-label" for="address" style="color: white;">Address:</label>

                    <textarea class="form-control" rows="7" id="address" placeholder="Address"></textarea>

                </div>

                <div class="form-group">

                    <button type="submit" class="btn btn-default" style="color: black;">Update</button>

                </div>

            </form>
        </div>

        <div class="col-sm-4 col-md-4">

        </div>








    </div>
</div>
</body>

</html>