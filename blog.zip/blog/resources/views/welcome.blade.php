@extends('layout')

@section('content')

    <div class="row">
        <div class="col-md-12">
            <h1>Welcome to Blog Application</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            @foreach($posts as $post)
                <div class="panel panel-default">
                    <div class="panel-heading"><h4>{{$post->title}}</h4></div>
                    <div class="panel-body">{{$post->description}}</div>
                    <div class="panel-footer"><h4>Comments</h4>
                        <ul>
                            @foreach($post->comments as $comment)
                                <li>
                                    {{$comment->comment}}<br>
                                    Posted by {{$comment->user->name}} before {{\Carbon\Carbon::parse($comment->created_at)->diffForHumans()}}
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="panel-footer">
                        @if(\Auth::guest())
                            <a href="/login">Login to comment</a>
                        @else
                            <form method="post" action="{{route('comment.store')}}">
                                <input type="hidden" name="blog_post_id" value="{{$post->id}}">
                                {!! csrf_field() !!}
                                <div class="form-group">
                                    <input class="form-control" type="text" name="comment" required />
                                </div>
                                <input class="form-control" type="submit" value="Comment" required />
                            </form>
                        @endif
                    </div>
                </div>
            @endforeach
            {!! $posts->links()!!}
        </div>
    </div>

@stop